package com.zevex.cashier

object NotificationParser {
    data class Payment(val amount: Double, val utr: String)

    fun parse(pkg: String, title: String, text: String): Payment? {
        val full = "$title $text".replace("\n", " ").trim()

        val recvWords = listOf("received", "you have received", "has been received", "credited", "credit of")
        if (recvWords.none { full.contains(it, ignoreCase = true) }) return null

        if (listOf("sent", "debited", "transferred to", "paid to").any { full.contains(it, ignoreCase = true) }
            && !full.contains("paid to you", true)) return null

        val amtRx = Regex("(?:₹|rs\\.?\\s*|inr\\s*)([0-9][0-9,]*\\.?[0-9]*)", RegexOption.IGNORE_CASE)
        val m = amtRx.find(full) ?: return null
        val amount = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
        if (amount <= 0.0) return null

        var utr = ""
        val pats = listOf(
            Regex("(?:utr|rrn|bank\\s*ref(?:erence)?(?:\\s*no\\.?)?)\\s*[:\\-]?\\s*([A-Za-z0-9]{6,30})", RegexOption.IGNORE_CASE),
            Regex("(?:transaction\\s*id|txn\\s*id|with\\s+id)\\s*[:\\-]?\\s*([A-Za-z0-9]{6,30})", RegexOption.IGNORE_CASE),
            Regex("\\b(\\d{12})\\b")
        )
        for (rx in pats) { val r = rx.find(full); if (r != null) { utr = r.groupValues[1]; break } }

        return Payment(amount, utr)
    }
}