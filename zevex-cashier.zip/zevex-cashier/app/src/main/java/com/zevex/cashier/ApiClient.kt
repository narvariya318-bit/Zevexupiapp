package com.zevex.cashier

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    fun hmac(secret: String, data: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(), "HmacSHA256"))
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun register(base: String, serverCode: String, appType: String,
                 deviceId: String, deviceName: String): JSONObject {
        val body = FormBody.Builder()
            .add("server_code", serverCode)
            .add("app_type", appType)
            .add("device_id", deviceId)
            .add("device_name", deviceName)
            .build()
        val req = Request.Builder().url("$base/api/cashier_register.php").post(body).build()
        client.newCall(req).execute().use { resp ->
            return JSONObject(resp.body?.string() ?: "{}")
        }
    }

    fun sendEvent(prefs: Prefs, amount: Double, utr: String, raw: String): Boolean {
        val ts = (System.currentTimeMillis() / 1000).toString()
        val amt = String.format("%.2f", amount)
        val sig = hmac(prefs.appSecret, "${prefs.instanceId}|${prefs.appType}|$amt|$utr|$ts")
        val body = FormBody.Builder()
            .add("instance", prefs.instanceId)
            .add("app", prefs.appType)
            .add("amount", amt)
            .add("utr", utr)
            .add("ts", ts)
            .add("device_id", android.os.Build.FINGERPRINT.take(90))
            .add("raw", raw.take(400))
            .add("sig", sig)
            .build()
        val req = Request.Builder().url("${prefs.apiBase}/api/cashier_events.php").post(body).build()
        return try { client.newCall(req).execute().use { it.isSuccessful } } catch (e: IOException) { false }
    }
}