package com.zevex.cashier

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        val apiBase = findViewById<EditText>(R.id.apiBase)
        val appSel  = findViewById<Spinner>(R.id.appSel)
        val codeIn  = findViewById<EditText>(R.id.serverCode)
        val btnReg  = findViewById<Button>(R.id.btnRegister)
        val btnPerm = findViewById<Button>(R.id.btnPerm)
        val btnBat  = findViewById<Button>(R.id.btnBattery)
        val status  = findViewById<TextView>(R.id.status)
        val appCodeBox   = findViewById<LinearLayout>(R.id.appCodeBox)
        val appCodeValue = findViewById<TextView>(R.id.appCodeValue)
        val btnCopyApp   = findViewById<Button>(R.id.btnCopyApp)

        apiBase.setText(if (prefs.apiBase.isNotEmpty()) prefs.apiBase else "https://zevex.in")

        val apps = arrayOf("googlepay", "phonepe")
        appSel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, apps)
        appSel.setSelection(apps.indexOf(prefs.appType).coerceAtLeast(0))

        if (prefs.appCode.isNotEmpty()) {
            showCode(appCodeBox, appCodeValue, prefs.appCode)
            status.text = "Registered\n\n1) Website pe App Code paste karo aur Verify karo\n2) Niche wale 2 buttons dabao"
        }

        btnCopyApp.setOnClickListener {
            val c = prefs.appCode
            if (c.isNotEmpty()) {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("App Code", c))
                Toast.makeText(this, "App Code copied", Toast.LENGTH_SHORT).show()
            }
        }

        btnPerm.setOnClickListener {
            try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        btnBat.setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }

        btnReg.setOnClickListener {
            val base = apiBase.text.toString().trim().trimEnd('/')
            if (base.isEmpty() || !base.startsWith("http")) {
                Toast.makeText(this, "API base URL sahi daalo", Toast.LENGTH_LONG).show(); return@setOnClickListener
            }
            val code = codeIn.text.toString().replace(Regex("\\D"), "")
            val type = apps[appSel.selectedItemPosition]
            if (code.length != 12) { Toast.makeText(this, "Server code 12 digit ka", Toast.LENGTH_LONG).show(); return@setOnClickListener }

            prefs.apiBase = base
            btnReg.isEnabled = false
            btnReg.text = "Registering..."

            thread {
                try {
                    val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: ""
                    val j = ApiClient.register(base, code, type, deviceId, Build.MODEL)
                    runOnUiThread {
                        btnReg.isEnabled = true; btnReg.text = "Register with Server"
                        if (j.optBoolean("ok")) {
                            prefs.appType = type
                            prefs.appCode = j.optString("app_code")
                            prefs.instanceId = j.optString("instance_id")
                            if (j.has("secret")) prefs.appSecret = j.optString("secret")
                            showCode(appCodeBox, appCodeValue, prefs.appCode)
                            status.text = "Registered\n\n1) Website pe App Code paste karo aur Verify karo\n2) Niche wale 2 buttons dabao"
                        } else {
                            Toast.makeText(this, "Error: " + j.optString("msg"), Toast.LENGTH_LONG).show()
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        btnReg.isEnabled = true; btnReg.text = "Register with Server"
                        Toast.makeText(this, "Network error: " + e.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun showCode(box: LinearLayout, value: TextView, code: String) {
        box.visibility = View.VISIBLE
        value.text = code.chunked(3).joinToString(" ")
    }
}