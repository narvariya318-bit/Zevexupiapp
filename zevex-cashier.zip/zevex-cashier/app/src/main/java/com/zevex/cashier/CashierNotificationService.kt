package com.zevex.cashier

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import kotlin.concurrent.thread

class CashierNotificationService : NotificationListenerService() {
    private val TAG = "ZXCashier"
    private val pkgMap = mapOf(
        "com.google.android.apps.nbu.paisa.user"     to "googlepay",
        "com.google.android.apps.nbu.paisa.merchant" to "googlepay",
        "com.phonepe.app"                            to "phonepe",
        "com.phonepe.app.business"                   to "phonepe",
        "com.phonepe.app.business.lite"              to "phonepe"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val type = pkgMap[sbn.packageName] ?: return
            val extras = sbn.notification.extras
            val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
            val text  = extras.getString(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

            val prefs = Prefs(this)
            if (!prefs.isRegistered) return

            val p = NotificationParser.parse(sbn.packageName, title, text) ?: return
            Log.i(TAG, "detected [$type] amount=${p.amount} utr=${p.utr}")
            prefs.appType = type
            thread {
                val ok = ApiClient.sendEvent(prefs, p.amount, p.utr, "$title | $text")
                Log.i(TAG, "event sent=$ok")
            }
        } catch (e: Exception) { Log.e(TAG, "err", e) }
    }
}