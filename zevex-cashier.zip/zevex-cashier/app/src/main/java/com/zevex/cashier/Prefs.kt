package com.zevex.cashier

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("zx", Context.MODE_PRIVATE)
    var appCode: String
        get() = sp.getString("app_code", "") ?: ""
        set(v) { sp.edit().putString("app_code", v).apply() }
    var instanceId: String
        get() = sp.getString("instance_id", "") ?: ""
        set(v) { sp.edit().putString("instance_id", v).apply() }
    var apiBase: String
        get() = sp.getString("api_base", "https://zevex.in") ?: "https://zevex.in"
        set(v) { sp.edit().putString("api_base", v).apply() }
    var appSecret: String
        get() = sp.getString("app_secret", "") ?: ""
        set(v) { sp.edit().putString("app_secret", v).apply() }
    var appType: String
        get() = sp.getString("app_type", "googlepay") ?: "googlepay"
        set(v) { sp.edit().putString("app_type", v).apply() }
    val isRegistered: Boolean get() = instanceId.isNotEmpty() && appSecret.isNotEmpty()
}